package com.imatia.formaciones.lvl3_pruebas.junit.classes;

public class InsufficientBalanceException extends Exception{

    public InsufficientBalanceException(String message) {
        super(message);
    }
}
