package com.imatia.formaciones.lvl3_pruebas.junit.classes;

import org.junit.jupiter.api.*;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;

class Ejercicio78Test {

    Account a1;
    Account a2;

    @BeforeEach
    void setUp() {
        this.a1 = new Account(new Branch(), "0011223344");
        this.a2 = new Account(new Branch(), "1122334455");
    }

    @RepeatedTest(5)
    @DisplayName("Test if could add balance simple")
    void testAddBalanceRepeated(){
        this.a1.addBalance(new BigDecimal("20.14"));
        this.a1.addBalance(new BigDecimal("100"));
        assertEquals(this.a1.getBalance(), new BigDecimal("120.14"));
    }

    @RepeatedTest(value = 5, name = "Repeat number {currentRepetition} of {totalRepetitions}")
    @DisplayName("Test if could add balance custom message")
    void testAddBalanceRepeatedName(){
        this.a1.addBalance(new BigDecimal("20.14"));
        this.a1.addBalance(new BigDecimal("100"));
        assertEquals(this.a1.getBalance(), new BigDecimal("120.14"));
    }

    @RepeatedTest(value = 5, name = "{displayName} - Repeat number {currentRepetition} of {totalRepetitions}")
    @DisplayName("Test if could add balance name displayed")
    void testAddBalanceRepeatedDisplayName(){
        this.a1.addBalance(new BigDecimal("20.14"));
        this.a1.addBalance(new BigDecimal("100"));
        assertEquals(this.a1.getBalance(), new BigDecimal("120.14"));
    }

    @RepeatedTest(value = 5, name = "{displayName} - Repeat number {currentRepetition} of {totalRepetitions}")
    @DisplayName("Test if could add balance repetition info")
    void testAddBalanceRepeatedDisplayNameInfo(RepetitionInfo info){
        this.a1.addBalance(new BigDecimal("20.14"));
        this.a1.addBalance(new BigDecimal(String.valueOf(info.getCurrentRepetition() * 100)));
        assertEquals(this.a1.getBalance(), new BigDecimal("20.14").add(new BigDecimal(String.valueOf(info.getCurrentRepetition() * 100))));
    }


}