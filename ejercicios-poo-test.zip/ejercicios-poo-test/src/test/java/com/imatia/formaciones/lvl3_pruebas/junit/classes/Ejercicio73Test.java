package com.imatia.formaciones.lvl3_pruebas.junit.classes;

import org.junit.jupiter.api.*;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

class Ejercicio73Test {

    static Account a1;
    static Account a2;

    @BeforeAll
    static void beforeAll() {
        Ejercicio73Test.a1 = new Account(new Branch(),"0011223344");
        Ejercicio73Test.a2 = new Account(new Branch(),"1122334455");
    }

    @AfterAll
    static void afterAll() {
        System.out.println("a1 = " + Ejercicio73Test.a1.getBalance());
        System.out.println("End test");
    }

    @BeforeEach
    void setUp() {

        System.out.println("a1 = " + Ejercicio73Test.a1.getBankAccount());
        System.out.println("a2 = " + Ejercicio73Test.a2.getBankAccount());
    }

    @AfterEach
    void tearDown() {
        System.out.println("End test");
    }

    @Test
    @DisplayName("Test if accounts are different")
    void testDifferentAccounts() {
        Ejercicio73Test.a1.addBalance(new BigDecimal("220.24"));
        assertNotEquals(Ejercicio73Test.a1.getBankAccount(), Ejercicio73Test.a2.getBankAccount());
    }

    @Test
    @DisplayName("Test if could add balance")
    void testAddBalance(){
        Ejercicio73Test.a1.addBalance(new BigDecimal("20.14"));
        Ejercicio73Test.a1.addBalance(new BigDecimal("100"));
        assertEquals(Ejercicio73Test.a1.getBalance(), new BigDecimal("120.14"));
    }
}