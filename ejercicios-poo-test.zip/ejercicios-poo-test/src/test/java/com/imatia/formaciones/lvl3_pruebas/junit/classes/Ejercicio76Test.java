package com.imatia.formaciones.lvl3_pruebas.junit.classes;

import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.Calendar;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assumptions.*;

class Ejercicio76Test {

    Account a1;
    Account a2;

    @BeforeEach
    void setUp() {
        this.a1 = new Account(new Branch(),"0011223344");
        this.a2 = new Account(new Branch(),"1122334455");
    }

    @Test
    @DisplayName("Test if could add balance when minutes are even")
    void testAddBalance(){
        boolean even = Calendar.getInstance().get(Calendar.MINUTE) % 2 == 0;
        a2.addBalance(new BigDecimal("20.14"));
        a2.addBalance(new BigDecimal("100"));
        assertEquals(this.a2.getBalance(), new BigDecimal("120.14"));
        Assumptions.assumeTrue(even);
        a1.addBalance(new BigDecimal("20.14"));
        a1.addBalance(new BigDecimal("100"));
        assertEquals(this.a1.getBalance(), new BigDecimal("120.14"));
    }

    @Test
    @DisplayName("Test if could add balance when minutes are even or odd")
    void testAddBalanceEvenOdd(){
        boolean even = Calendar.getInstance().get(Calendar.MINUTE) % 2 == 0;
        assumingThat( even, () -> {
            a1.addBalance(new BigDecimal("20.14"));
            a1.addBalance(new BigDecimal("100"));
            assertEquals(this.a1.getBalance(), new BigDecimal("120.14"));
            System.out.println("IS TRUE");
        });

        assumingThat( !even, () -> {
            a1.addBalance(new BigDecimal("30.14"));
            a1.addBalance(new BigDecimal("100"));
            assertEquals(this.a1.getBalance(), new BigDecimal("130.14"));
            System.out.println("IS FALSE");
        });
    }

    @Test
    @DisplayName("Test if could add balance when minutes are even with executable")
    void testAddBalanceEvenAssumingExecutable(){
        boolean even = Calendar.getInstance().get(Calendar.MINUTE) % 2 == 0;
        assumingThat( even, () -> {
            a1.addBalance(new BigDecimal("20.14"));
            a1.addBalance(new BigDecimal("100"));
            assertEquals(this.a1.getBalance(), new BigDecimal("120.14"));
        });
        a2.addBalance(new BigDecimal("20.14"));
        a2.addBalance(new BigDecimal("100"));
        assertEquals(this.a2.getBalance(), new BigDecimal("120.14"));

    }


}