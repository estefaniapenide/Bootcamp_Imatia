package com.imatia.formaciones.lvl3_pruebas.junit.classes;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

class Ejercicio68Test {

    @Test
    void testUnsuccessfulWithdrawBalance(){
        Account a1 = new Account(new Branch(),"0011223344");
        a1.addBalance(new BigDecimal("20.14"));
        InsufficientBalanceException ex = assertThrows(InsufficientBalanceException.class, () -> {
            a1.withdrawalBalance(new BigDecimal("100"));
        });
        assertEquals(ex.getMessage(), "M_INSUFFICIENT_BALANCE");
    }

    @Test
    void testSuccessfulWithdrawBalance(){
        Account a1 = new Account(new Branch(),"0011223344");
        a1.addBalance(new BigDecimal("100"));
        assertDoesNotThrow(() -> a1.withdrawalBalance(new BigDecimal("20.14")));
        assertEquals(a1.getBalance(), new BigDecimal("79.86"));
    }


}