package com.imatia.formaciones.lvl3_pruebas.junit.classes;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

class Ejercicio72Test {

    Account a1;
    Account a2;

    @BeforeEach
    void setUp() {
        Account a1 = new Account(new Branch(),"0011223344");
        System.out.println("a1 = " + a1.getBankAccount());
        Account a2 = new Account(new Branch(),"1122334455");
        System.out.println("a2 = " + a2.getBankAccount());
    }

    @AfterEach
    void tearDown() {
        System.out.println("End test");
    }

    @Test
    @DisplayName("Test if accounts are differents ")
    void testDifferentAccounts() {
        Account a1 = new Account(new Branch(),"0011223344");
        Account a2 = new Account(new Branch(),"1122334455");
        assertNotEquals(a1.getBankAccount(),a2.getBankAccount());
    }

    @Test
    @DisplayName("Test if could add balance")
    void testAddBalance(){
        a1 = new Account(new Branch(),"0011223344");
        a1.addBalance(new BigDecimal("20.14"));
        a1.addBalance(new BigDecimal("100"));
        assertEquals(a1.getBalance(), new BigDecimal("120.14"));
    }
}