package com.imatia.formaciones.lvl3_pruebas.junit.classes;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class Ejercicio65Test {

    @Test
    void testNewBranch() {
        Branch b = new Branch();
        assertNotNull(b.getEntityID());
        assertNotNull(b.getBranchID());
    }

    @Test
    void testNewBranchWithParameters() {
        Branch b = new Branch("2095", "1471");
        assertEquals("2095", b.getEntityID());
        assertEquals("2096", b.getEntityID());
        assertEquals("1471", b.getBranchID());
    }
}