package com.imatia.formaciones.lvl3_pruebas.junit.classes;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.*;

import java.math.BigDecimal;
import java.util.Properties;

import static org.junit.jupiter.api.Assertions.*;

class Ejercicio74Test {

    Account a1;
    Account a2;

    @BeforeEach
    void setUp() {
        this.a1 = new Account(new Branch(),"0011223344");
        this.a2 = new Account(new Branch(),"1122334455");
    }

    @BeforeAll
    static void beforeAll() {
        System.out.println("---- SYSTEM PROPERTIES ----");
        Properties properties = System.getProperties();
        properties.forEach((key, value) -> System.out.println(key + " -> " + value));
        System.out.println("---- ------------------ ----");
    }

    @Test
    @DisplayName("Test if could add balance")
    @EnabledOnOs({OS.WINDOWS, OS.LINUX})
    void testAddBalanceOnWindowsAndLinux(){
        this.a1.addBalance(new BigDecimal("20.14"));
        this.a1.addBalance(new BigDecimal("100"));
        assertEquals(this.a1.getBalance(), new BigDecimal("120.14"));
    }

    @Test
    @DisplayName("Test if could add balance in other operative system")
    @DisabledOnOs(OS.WINDOWS)
    void testAddBalanceOtherThanWindows(){
        this.a1.addBalance(new BigDecimal("20.14"));
        this.a1.addBalance(new BigDecimal("100"));
        assertEquals(this.a1.getBalance(), new BigDecimal("120.14"));
    }

    @Test
    @DisplayName("Test if could add balance in Java 11")
    @EnabledOnJre(JRE.JAVA_11)
    void testAddBalanceJava11(){
        this.a1.addBalance(new BigDecimal("20.14"));
        this.a1.addBalance(new BigDecimal("100"));
        assertEquals(this.a1.getBalance(), new BigDecimal("120.14"));
    }

    @Test
    @DisplayName("Test if could add balance in not Java 11")
    @DisabledOnJre(JRE.JAVA_11)
    void testAddBalanceDisableJava11(){
        this.a1.addBalance(new BigDecimal("20.14"));
        this.a1.addBalance(new BigDecimal("100"));
        assertEquals(this.a1.getBalance(), new BigDecimal("120.14"));
    }

    @Test
    @DisplayName("Test if could add balance in user.country -> es")
    @EnabledIfSystemProperty(named = "user.language", matches = "es")
    void testAddBalanceOnSpanishLanguage(){
        this.a1.addBalance(new BigDecimal("20.14"));
        this.a1.addBalance(new BigDecimal("100"));
        assertEquals(this.a1.getBalance(), new BigDecimal("120.14"));
    }

    @Test
    @DisplayName("Test if could add balance in not user.country -> en")
    @DisabledIfSystemProperty(named = "user.language", matches = "en")
    void testAddBalanceOnEnglishLanguage(){
        this.a1.addBalance(new BigDecimal("20.14"));
        this.a1.addBalance(new BigDecimal("100"));
        assertEquals(this.a1.getBalance(), new BigDecimal("120.14"));
    }

}