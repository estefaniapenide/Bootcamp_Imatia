package com.imatia.formaciones.lvl3_pruebas.junit.classes;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.*;

import java.math.BigDecimal;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class Ejercicio75Test {

    Account a1;
    Account a2;

    @BeforeEach
    void setUp() {
        this.a1 = new Account(new Branch(),"0011223344");
        this.a2 = new Account(new Branch(),"1122334455");
    }

    @BeforeAll
    static void beforeAll() {
        System.out.println("---- SYSTEM ENVIROMENT ----");
        Map<String, String> getenv = System.getenv();
        getenv.forEach((key, value) -> System.out.println(key + " -> " + value));

    }

    @Test
    @DisplayName("Test if could add balance with number processors -> 8")
    @EnabledIfEnvironmentVariable(named = "NUMBER_OF_PROCESSORS", matches = "8")
    void testAddBalanceOnNumberProcessors(){
        this.a1.addBalance(new BigDecimal("20.14"));
        this.a1.addBalance(new BigDecimal("100"));
        assertEquals(this.a1.getBalance(), new BigDecimal("120.14"));
    }

    @Test
    @DisplayName("Test if could add balance with number processors -> not 2")
    @DisabledIfEnvironmentVariable(named = "NUMBER_OF_PROCESSORS", matches = "2")
    void testAddBalanceOnNumberProcessorsNot2(){
        this.a1.addBalance(new BigDecimal("20.14"));
        this.a1.addBalance(new BigDecimal("100"));
        assertEquals(this.a1.getBalance(), new BigDecimal("120.14"));
    }
}