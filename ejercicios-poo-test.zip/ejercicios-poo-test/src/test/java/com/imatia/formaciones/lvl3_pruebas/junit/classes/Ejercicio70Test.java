package com.imatia.formaciones.lvl3_pruebas.junit.classes;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class Ejercicio70Test {

    @Test
    void testAccountBelongsToBranch() {
        Branch b = new Branch("2095", "1471");
        Account a = new Account(new Branch("2095", "1471"));
        assertEquals(b.getBranchID(), a.getBranchID());
    }

    @Test
    void testMultipleAccountBelongsToBranch() {
        Branch b = new Branch("2095", "1471");
        Account a1 = new Account(new Branch("2095", "1471"));
        Account a2 = new Account(new Branch());
        Account a3 = new Account(new Branch());
        assertEquals(b.getBranchID(), a1.getBranchID());
//        assertEquals(b.getBranchID(), a3.getBranchID());
//        assertEquals(b.getBranchID(), a2.getBranchID());
    }

    @Test
    void testMultipleAccountBelongsToBranchWithAssert() {
        Branch b = new Branch("2095", "1471");
        Account a1 = new Account(new Branch("2095", "1471"));
        Account a2 = new Account(new Branch());
        Account a3 = new Account(new Branch());
        assertAll(() -> {
                    assertEquals(b.getBranchID(), a1.getBranchID(), () -> "M_NOT_SAME_ACCOUNT_1");
                }
                ,() -> {
                    assertEquals(b.getBranchID(), a2.getBranchID(), () -> "M_NOT_SAME_ACCOUNT_2");
                },
                () -> {
                    assertEquals(b.getBranchID(), a3.getBranchID(), () -> "M_NOT_SAME_ACCOUNT_3");
                }
                );
    }


}