package com.imatia.formaciones.lvl3_pruebas.junit.classes;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

class Ejercicio67Test {

    @Test
    void testDifferentAccounts() {
        Account a1 = new Account(new Branch(),"0011223344");
        Account a2 = new Account(new Branch(),"1122334455");
        assertNotEquals(a1.getBankAccount(),a2.getBankAccount());
    }

    @Test
    void testAddBalance(){
        Account a1 = new Account(new Branch(),"0011223344");
        a1.addBalance(new BigDecimal("20.14"));
        a1.addBalance(new BigDecimal("100"));
        assertEquals(a1.getBalance(), new BigDecimal("120.14"));
    }

    @Test
    void testAddBalanceToRandomAccount() {
        Account a1 = new Account(new Branch());
        a1.addBalance(new BigDecimal("100"));
        a1.addBalance(new BigDecimal("20.14"));
        assertEquals(a1.getBalance(), new BigDecimal("120.14"));
    }
}