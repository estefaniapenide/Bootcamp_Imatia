package com.imatia.formaciones.lvl3_pruebas.junit.classes;

import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import static org.junit.jupiter.api.Assertions.*;

class Ejercicio79Test {

    Account a1;
    Account a2;

    @BeforeEach
    void setUp() {
        this.a1 = new Account(new Branch(), "0011223344");
        this.a2 = new Account(new Branch(), "1122334455");
    }

    @ParameterizedTest
    @ValueSource(strings = {"250", "500", "750", "1000"})
    @DisplayName("Test withdrawal with enough balance -> Value Source")
    void withdrawalBalanceTest(String value) {
        this.a1.addBalance(new BigDecimal("1000"));
        assertDoesNotThrow(() -> {
            this.a1.withdrawalBalance(new BigDecimal(value));
        });
    }

    @ParameterizedTest(name = "{index} - Withdrawal specific balance: {0}")
    @ValueSource(strings = {"250", "500", "750", "1000"})
    @DisplayName("Test withdrawal with enough balance -> Value Source with name")
    void withdrawalBalanceTestWithName(String value) {
        this.a1.addBalance(new BigDecimal("1000"));
        assertDoesNotThrow(() -> {
            this.a1.withdrawalBalance(new BigDecimal(value));
        });
    }

    @ParameterizedTest
    @CsvSource({"400,250", "600,500", "800,750", "1250,1000"})
    @DisplayName("Test withdrawal with enough balance -> CSV Source")
    void withdrawalBalanceTest(String amount, String value) {
        System.out.println("Balance: " + amount + ", Amount: " + value);
        this.a1.addBalance(new BigDecimal(amount));
        assertDoesNotThrow(() -> {
            this.a1.withdrawalBalance(new BigDecimal(value));
        });
    }

    @ParameterizedTest
    @CsvFileSource(resources = "/testDataCSV.csv")
    @DisplayName("Test withdrawal with enough balance -> CSV File")
    void withdrawalBalanceTestCsvFile(String value) {
        this.a1.addBalance(new BigDecimal("1000"));
        assertDoesNotThrow(() -> {
            this.a1.withdrawalBalance(new BigDecimal(value));
        });
    }

    @ParameterizedTest
    @MethodSource("amountGenerator")
    @DisplayName("Test withdrawal with enough balance -> Method")
    void withdrawalBalanceTestMethodSource(String value) {
        this.a1.addBalance(new BigDecimal("1000"));
        assertDoesNotThrow(() -> {
            this.a1.withdrawalBalance(new BigDecimal(value));
        });
    }

    static List<String> amountGenerator() {
        List<String> list = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            list.add(String.valueOf(ThreadLocalRandom.current().nextInt(250,1000)));
        }
        return list;
    }
}