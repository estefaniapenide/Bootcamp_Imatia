package com.imatia.formaciones.lvl3_pruebas.junit.classes;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class Ejercicio66Test {

        @Test
        void testSameEntity() {
            Branch b1 = new Branch("2095", "1471");
            Branch b2 = new Branch("2095");
            assertEquals(b1.getEntityID(), b2.getEntityID());
        }

        @Test
        void testDifferentBranches() {
            Branch b1 = new Branch();
            Branch b2 = new Branch();
            assertNotEquals(b1.getEntityID().concat(b1.getBranchID()), b2.getEntityID().concat(b2.getBranchID()));
        }
}