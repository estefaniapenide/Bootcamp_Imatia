# ejercicios-poo
Ejercicios de programacion orientada a objetos que se correlan con la presentación en powerpoint, de manera que proporciona recursos ejecutables para cada uno de los temas que se van proponiendo a los alumnos.

Entre los recursos proporcionados a los formadores de CampusDual, se proporciona una presentación en PowerPoint con diferentes lecciones básicas de Porgramación orientada a objetos (en adelante POO) basada en Java.

Como parte de estas lecciones, los ejemplos de código y ejercicios a los que la presentación hace referencia están disponibles en este proyecto, listo para descargar y ejecutar en cualquier IDE, de manera que cualquier formador pueda tenerlos disponibles y listos para utilizar de manera sencilla y directa, como apoyo de cara a explicar a los alumnos el correcto funcionamiento de cada caso y poder jugar con valores, configuraciones, etc...

Contiene una rama principal "***main***", que contiene todos los ejericios relacionados con programación básica, hilos, programación funcional y Junit.

Contiene una rama secundaria "***mockito***", que contiene el ejercicio de backend con 3 ejemplos sobre pruebas unitarias con Mockito. Cuando se cambie a esta rama, el proyecto de la rama main dejará de estar disponible ya que modifica el fichero pom.xml en la raíz, aunque el resto del proyecto siga existiendo.

## Referencias:
Indice de recursos docentes en el [SharePoint de CampusDual](https://campusdual.sharepoint.com/sites/tutores.fullstack/SitePages/Material-general-para-formaciones.aspx)
