
# Ontimize Boot

- Enter the parent directory and run an install:
	
		mvn install

## Start the database

 Enter the `model` folder and execute the command

		mvn exec:java -Prun_database
	
## Start the server: 
 - Go to the `boot` folder and run the command

		mvn spring-boot:run
	
Use the following URL to access the [https://localhost:33333/](https://localhost:33333/) application 
